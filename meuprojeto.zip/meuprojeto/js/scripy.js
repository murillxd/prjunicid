// MÁSCARA DE CPF
function mascaraCPF(campo) {

    let valor = campo.value.replace(/\D/g, '');

    valor = valor.substring(0, 11);

    valor = valor.replace(
        /(\d{3})(\d)/,
        '$1.$2'
    );

    valor = valor.replace(
        /(\d{3})(\d)/,
        '$1.$2'
    );

    valor = valor.replace(
        /(\d{3})(\d{1,2})$/,
        '$1-$2'
    );

    campo.value = valor;
}


// MÁSCARA DE TELEFONE
function mascaraTelefone(campo) {

    let valor = campo.value.replace(/\D/g, '');

    valor = valor.substring(0, 11);

    valor = valor.replace(
        /^(\d{2})(\d)/,
        '($1) $2'
    );

    valor = valor.replace(
        /(\d{5})(\d)/,
        '$1-$2'
    );

    campo.value = valor;
}


// MÁSCARA DE CEP
function mascaraCEP(campo) {

    let valor = campo.value.replace(/\D/g, '');

    valor = valor.substring(0, 8);

    valor = valor.replace(
        /^(\d{5})(\d)/,
        '$1-$2'
    );

    campo.value = valor;
}